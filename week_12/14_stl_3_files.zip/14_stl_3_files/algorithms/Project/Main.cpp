#include <iostream>
#include <string>
#include <iterator>  
#include <algorithm>
#include <vector>
#include <list>
#include <deque>
#include <set>
#include <map>

using namespace std;

#include "Function_binary_search.h"
#include "Function_fill.h"
#include "Function_fill_n.h"
#include "Function_find.h"
#include "Function_remove.h"
#include "Function_remove_if.h"
#include "Function_replace.h"
#include "Function_replace_if.h"
#include "Function_reverse.h"
#include "Function_rotate.h"
#include "Function_sort.h"

int main()
{	

	/* 
		NOTE: The list of containers you can use with these functions is not complete.
			  You are responsible only for the containers listed in each function.
	*/

	//function_binary_search();
	
	//function_fill();

	//function_fill_n();

	//function_find();

	//function_remove();

	//function_remove_if();

	//function_replace();

	//function_replace_if();

	//function_reverse();

	function_rotate();

	//function_sort();


	cout << endl;
	system("Pause");
	return 0;
}

