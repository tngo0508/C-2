#include "CandidateList.h"

// Function definitions