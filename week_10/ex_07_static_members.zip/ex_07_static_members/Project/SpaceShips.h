#ifndef SPACESHIPS_H
#define SPACESHIPS_H

#include <iostream>

using namespace std;

const int BONUS = 50;

class SpaceShips
{
public:

	//Function declarations


private:
	static int totalSpaceShips;
	static int totalPoints;	
	int points;
	bool bonus;
};

#endif