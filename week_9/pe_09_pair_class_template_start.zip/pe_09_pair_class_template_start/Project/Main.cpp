#include "Pair.h"

#include <iostream>
#include <string>
using namespace std;

int main()
{
	Pair pInt1(1, 2), pInt2(4, 7);

	cout << "First pair: ";
	pInt1.print();
	cout << "\nSecond pair: ";
	pInt2.print();	
	
	cout << endl;
	system("Pause");
	return 0;
}

