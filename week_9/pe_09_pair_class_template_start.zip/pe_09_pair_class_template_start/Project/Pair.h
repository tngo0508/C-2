#ifndef PAIR_H
#define PAIR_H

#include <iostream>
using namespace std;

class Pair
{
public:
    Pair();
	Pair(int firstValue, int secondValue);

	void setFirst(int newFirst);
	void setSecond(int newSecond);

	int getFirst() const;
	int getSecond() const;

	void print() const;

	~Pair();

private:
	int first;
	int second;
};

#endif 