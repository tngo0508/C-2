#include "Pair.h"

Pair::Pair()
{
	int first = 0;
	int second = 0;
}

Pair::Pair(int firstValue, int secondValue)
{
    first = firstValue;
    second = secondValue;
}

int Pair::getFirst() const
{
    return first;
}

int Pair::getSecond() const
{
    return second;
}

void Pair::setFirst(int newFirst)
{
	first = newFirst;
}

void Pair::setSecond(int newSecond)
{
	second = newSecond;
}

void Pair::print() const
{
	cout << "<" << first << ", " << second << ">" << endl;
}

Pair::~Pair()
{}

